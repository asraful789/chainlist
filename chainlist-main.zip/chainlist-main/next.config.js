module.exports = {
  // i18n: {
  //   locales: ["en", "zh"],
  //   defaultLocale: "en",
  // },
  reactStrictMode: true,
};
